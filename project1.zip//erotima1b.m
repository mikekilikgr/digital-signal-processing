%erotima B askhsi 1

poloi=[1 -0.7 -0.18];
miden=[0 0.2 0];

%etsi to grafei sto doc matlab gia ti sinartisi metaforas
sys=tf(miden,poloi);
%roots of quadratic polynomial
m1=roots(miden);
p1=roots(poloi);
%zero-pole plot descrete time system
figure(1);
zplane(m1,p1);
title('Διάγραμμα πόλων-μηδενικών Η(z)');


%erotima D askhsi 1

n=-pi:pi/128:pi;
figure(2);
freqz(miden,poloi,n);
title('Αποκριση συχνότητας συστήματος');
figure(3);
freqz(miden,poloi);
title('Αποκριση συχνότητας συστήματος χωρίς ορισμένο διάστημα');


%erotima E askhsi 1 
poloi=[1 -1.7 0.52 0.18];
miden=[0 0.2 0];

figure(4);
freqz(miden,poloi,n);
title('Frequency Response');


%erotima A askhsi 2
%symbolic variable
syms z;
% converts a discrete time system  to partial fraction expansion
[r,p,k]=residuez([4 -3.5 0],[1 -2.5 1]);
H=z*r(1)/(z-p(1))+z*r(2)/(z-p(2))+k;
% prints H in a plain-text format that resembles typeset mathematics.
pretty(H);
%erotima B askhsi 2
%inverse z transorm
Hinv=iztrans(H);
pretty(Hinv);



