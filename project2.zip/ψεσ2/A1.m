%EROTIMA 1

Fs=10^4;
%zoni passband 3db
Rp=3;
%zoni stopband 30db
Rs=30;
%2pif
Ws=2*pi*3*10^3;
Wp=2*pi*4*10^3;

%[n,Wn] = buttord(Wp,Ws,Rp,Rs,'s')
%n -> lowest order
%Wn cutoff frequency for analog Butterworth filter

[n,Wn] = buttord(Wp,Ws,Rp,Rs,'s');

%buttap Butterworth filter prototype
%k ipoloipo sinartisis
[z,p,k] = buttap(n);
%zp2tf Convert zero-pole-gain filter parameters
% to transfer function form
%αναπαριστούμε το φίλτρο με μορφή συνάρτησης μεταφοράς
[NUM,DEN] = zp2tf(z,p,k);
%lp2lp  Change cutoff frequency for lowpass
% analog filter
%μετασχηματίσαμε την συχνότητα της συνάρτησης μεταφοράς στην συγκεκριμένη συχνότητα αποκοπής
[NUMT,DENT] = lp2lp(NUM,DEN,Wn);
%freqs Frequency response of analog filter

DF=(Fs/2)/2048;
f=0:DF:Fs/2-DF;

figure(1)
HB1=freqs(NUMT,DENT,2048);


[NUMd1,DENd1] = bilinear(NUMT,DENT,Fs);

HB2=freqz(NUMd1,DENd1,2048);
hold on;
plot(f,20*log(abs(HB1)),f,20*log(abs(HB2)))
axis([0 5000 -700 100])
xlabel('f(Hz)');
ylabel('H(f)  (dB)');
title('Aπόκριση συχνότητας αναλογικού και ψηφιακού φίλτρου Butterworth με εξασθένιση 30dB');
legend('Απόκριση Συχνότητας αναλογικού φίλτρου','Απόκριση Συχνότητας ψηφιακού φίλτρου');

