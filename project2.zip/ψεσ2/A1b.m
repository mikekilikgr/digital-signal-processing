
%Epanalambanw gia 50dB 

Rs=50;

[N,Wn]=buttord(Wp,Ws,Rp,Rs,'s');
[z,p,k] = buttap(N);
[NUM,DEN] = zp2tf(z,p,k);
[NUMT,DENT] = lp2lp(NUM,DEN,Wn);
figure(2)
HB3=freqs(NUMT,DENT,2048);

[NUMd2,DENd2] = bilinear(NUMT,DENT,Fs);

HB4=freqz(NUMd2,DENd2,2048);

plot(f,20*log(abs(HB3)),f,20*log(abs(HB4)))
axis([0 5000 -700 100])
xlabel('f(Hz)');
ylabel('H(f)  (dB)');
title('Aπόκριση συχνότητας αναλογικού και ψηφιακού φίλτρου Butterworth με εξασθένιση 50dB');
legend('Απόκριση Συχνότητας αναλογικού φίλτρου','Απόκριση Συχνότητας ψηφιακού φίλτρου');
