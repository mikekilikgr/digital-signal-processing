%a2
fs=10000;
Ts=1/fs;
N=500;
n=0:N-1;
xt = 1+cos(1000*n*Ts)+cos(16000*n*Ts)+cos(30000*n*Ts);
y = filter(NUMd2,DENd2,xt);
Y=fftshift(fft(y));
figure(6);
subplot(2,1,1);
stem(n*Ts,y)
xlabel('t(sec)');
ylabel('x(n*Ts)');
title('Sampled X(t) after Butterworth(50dB attenuation)');
subplot(2,1,2);
F = [-fs/2 : fs/500 :fs/2 - fs/500];
plot(F,abs(Y))
xlabel('f(Hz)');
ylabel('X(f)');
title('Spectrum of sampled x(t)');

%b
fs=5;
Ts=1/fs;
N=500;
n=0:N-1;
xt = 1+cos(1.5*n*Ts) + cos(5*n*Ts);
figure(7);
subplot(2,1,1);
stem(n*Ts,xt)
xlabel('t(sec)');
ylabel('x(n*Ts)');
title('X(t),500 samples, fs=5kHz');

F = -fs/2 : fs/500 :fs/2 - Fs/500 ;
Xf = fftshift(fft(xt));
subplot(2,1,2);
plot(F,abs(Xf));
xlabel('f(Hz)');
ylabel('X(f)');
title('Spectrum of sampled x(t)');

y = filter(b1,a1,xt);
Y=fftshift(fft(y));
figure(8);
subplot(2,1,1);
stem(n*Ts,y)
xlabel('t(sec)');
ylabel('x(n*Ts)');
title('X(t) , after Chebyshev n=16');
subplot(2,1,2);
plot(F,abs(Y))
xlabel('f(Hz)');
ylabel('X(f)');
title('Spectrum of sampled X(t)');
