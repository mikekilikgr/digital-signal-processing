%EROTIMA 2

%a
n1=2;
n2=16;
wc=2;
fc=wc/(2*pi);
Ts=0.2;
Fs=1/Ts;
Pripple=3;
Wp = fc/(Fs/2);


[b1,a1] = cheby1(n1,Pripple,Wp,'high');
[b2,a2] = cheby1(n2,Pripple,Wp,'high');

HC1 = freqz(b1,a1,256);
HC2 = freqz(b2,a2,256);

DF=1/256;
f=0:DF:1-DF;

figure(3);
plot(f,20*log(abs(HC1)),f,20*log(abs(HC2)))
xlabel('f(Hz)');
ylabel('H(f)  (dB)');
title('Απόκριση συχνότητας ψηφιακού φίλτρου Chebyshev');
legend('n=2','n=16');


