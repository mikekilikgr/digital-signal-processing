%erotima 3
%a1
fs=10000;
Ts=1/fs;
N=500;
n=0:N-1;
xt = 1+cos(1000*n*Ts)+cos(16000*n*Ts)+cos(30000*n*Ts);
figure(4);
subplot(2,1,1);
stem(n*Ts,xt)
xlabel('t(sec)');
ylabel('x(n*Ts)');
title('X(t),500 samples, fs=10kHz');

F = [-fs/2 : fs/500 :fs/2 - fs/500];
Xf = fftshift(fft(xt));
subplot(2,1,2);
plot(F,abs(Xf));
xlabel('f(Hz)');
ylabel('X(f)');
title('Spectrum of sampled x(t)');

y = filter(NUMd1,DENd1,xt);
Y=fftshift(fft(y));
figure(5);
subplot(2,1,1);
stem(n*Ts,y)
xlabel('t(sec)');
ylabel('x(n*Ts)');
title('Sampled X(t) after Butterworth(30dB attenuation)');
subplot(2,1,2);
plot(F,abs(Y))
xlabel('f(Hz)');
ylabel('X(f)');
title('Spectrum of sampled x(t)');

