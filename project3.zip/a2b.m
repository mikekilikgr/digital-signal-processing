Fs=100;
Ts = 1 /Fs;
N=400;
n=0:N-1;
x = sin(15*n*Ts) + 0.25*sin(200*n*Ts);

X = fftshift(fft(x));
F = [-Fs/2 : Fs/N :Fs/2 - Fs/N];

x1 = filter(b3,1,x);
X1 = fftshift(fft(x1));
figure(4);
plot(F, abs(X1), F , abs(X))
title('Αναπαράσταση φάσματος δειγματοληπτημένου σήματος με Fs=100Hz')
xlabel('F(Hz)');
ylabel('|H(F)|');
legend('Φάσμα με Hamming Ν=21','Φάσμα δειγματοληπτημένου σήματος');

x2 = filter(b4,1,x);
X2 = fftshift(fft(x2));
figure(5);
plot(F, abs(X2), F , abs(X))
title('Αναπαράσταση φάσματος δειγματοληπτημένου σήματος με Fs=100Hz')
xlabel('F(Hz)');
ylabel('|H(F)|');
legend('Φάσμα με Hamming Ν=41','Φάσμα δειγματοληπτημένου σήματος');

x3 = filter(b5,1,x);
X3 = fftshift(fft(x3));
figure(6);
plot(F, abs(X3), F , abs(X))
title('Αναπαράσταση φάσματος δειγματοληπτημένου σήματος με Fs=100Hz')
xlabel('F(Hz)');
ylabel('|H(F)|');
legend('Φάσμα με Hanning Ν=21','Φάσμα δειγματοληπτημένου σήματος');

x4 = filter(b6,1,x);
X4 = fftshift(fft(x4));
figure(7);
plot(F, abs(X4), F , abs(X))
title('Αναπαράσταση φάσματος δειγματοληπτημένου σήματος με Fs=100Hz')
xlabel('F(Hz)');
ylabel('|H(F)|');
legend('Φάσμα με Hanning Ν=41','Φάσμα δειγματοληπτημένου σήματος');
