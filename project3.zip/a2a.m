Wc = 0.5*pi;
Fs = 100;
Fc = Wc/2*pi;
Wn = Fc/(Fs/2);


b3 = fir1(21-1,Wn,'low',hamming(21));
b4 = fir1(41-1,Wn,'low',hamming(41));
b5 = fir1(21-1,Wn,'low',hanning(21));
b6 = fir1(41-1,Wn,'low',hanning(41));

[h3,w3] = freqz(b3,1,512);
[h4,w4] = freqz(b4,1,512);
[h5,w5] = freqz(b5,1,512);
[h6,w6] = freqz(b6,1,512);

figure(2);
subplot(1,2,1);
plot(w3,abs(h3))
title(' Hamming - N=21')
xlabel('ω(r/s)');
ylabel('|H(e^jω)|');
subplot(1,2,2);
plot(w4,abs(h4))
title('Hamming - Ν=41')
xlabel('ω(r/s)');
ylabel('|H(e^jω)|');


figure(3);
subplot(1,2,1);
plot(w5,abs(h5))
title('Hanning - Ν=21')
xlabel('ω(r/s)');
ylabel('|H(e^jω)|');
subplot(1,2,2);
plot(w6,abs(h6))
title('Hanning - Ν=41')
xlabel('ω(r/s)');
ylabel('|H(e^jω)|');
