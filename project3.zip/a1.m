
Wc = 0.4*pi;
Fs = 100;
Fc = Wc/2*pi;
Wn = Fc/(Fs/2);
N = 21;

b1 = fir1(N-1,Wn,'low',rectwin(N));
b2 = fir1(N-1,Wn,'low',hamming(N));

[h1,w1] = freqz(b1,1,512);
[h2,w2] = freqz(b2,1,512);

figure();
plot(w1,abs(h1),w2,abs(h2))
title('Απόκριση συχνότητας φίλτρων Rectangular και Hamming')
xlabel('ω(r/s)');
ylabel('|H(e^jω)|');
legend('Rectangular','Hamming');